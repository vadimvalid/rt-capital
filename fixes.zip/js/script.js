const toggleFilter = () => {
  const rtToggle = document.querySelector(".rt-toggle-collapse");
  const rtCollapse = document.querySelector(".rt-collapse");

  rtToggle.addEventListener("click", () => {
    rtToggle.classList.toggle("is-opened");
    rtCollapse.classList.toggle("is-opened");
  });
};
toggleFilter();
