(window.webpackJsonp = window.webpackJsonp || []).push([
  ["capital_app_head"],
  {
    "4oai": function (a, n, i) {
      "use strict";
      i.r(n);
      var o = i("EVdn"),
        p = i.n(o);
      window.$ = p.a;
    },
  },
  [["4oai", "runtime", 1]],
]);
